# Yılan Oyunu Projesi
import pygame
import time
import random
import asyncio



def kafa_arkasi_kutu(px, py, aci, ilerleme, boyut):
    """Kafanın hemen arkasındaki parçanın yalnızca kafa dışında kalan kısmını verir."""
    if aci == 270:   # Sağa gidiyor (sol kısım görünür)
        return pygame.Rect(px, py, ilerleme, boyut)
    elif aci == 90:  # Sola gidiyor (sağ kısım görünür)
        return pygame.Rect(px + boyut - ilerleme, py, ilerleme, boyut)
    elif aci == 0:   # Yukarı gidiyor (alt kısım görünür)
        return pygame.Rect(px, py + boyut - ilerleme, boyut, ilerleme)
    else:            # Aşağı gidiyor (üst kısım görünür)
        return pygame.Rect(px, py, boyut, ilerleme)

def kuyruk_onu_kutu(px, py, aci, ilerleme, boyut):
    """Kuyruğun hemen önündeki parçanın yalnızca kuyruk dışında kalan kısmını verir."""
    kalan = boyut - ilerleme
    if aci == 270:   # Sağa gidiyor (sağ kısım görünür)
        return pygame.Rect(px + ilerleme, py, kalan, boyut)
    elif aci == 90:  # Sola gidiyor (sol kısım görünür)
        return pygame.Rect(px, py, kalan, boyut)
    elif aci == 0:   # Yukarı gidiyor (üst kısım görünür)
        return pygame.Rect(px, py, boyut, kalan)
    else:            # Aşağı gidiyor (alt kısım görünür)
        return pygame.Rect(px, py + ilerleme, boyut, kalan)

async def main():
    pygame.init()
    SIYAH = (0, 0, 0)
    BEYAZ = (255, 255, 255)
    KIRMIZI = (255, 0, 0)

    # 1920 ve 1080 sayılarının ikisi de 60'a TAM BÖLÜNÜR (32x18 kare)!
    ekran_yatay = 1920
    ekran_dikey = 1080
    ekran = pygame.display.set_mode((ekran_yatay, ekran_dikey), pygame.FULLSCREEN | pygame.SCALED)
    
    BOYUT = 60
    ADIM_HIZI = 6  # 60 FPS'te her karede 6 piksel kayar (60 / 6 = 10 karede 1 tam hücre)
    
    grid_x = 180
    grid_y = 0
    hız_x = BOYUT
    hız_y = 0
    yon_acisi = 270
    sonraki_yon = (BOYUT, 0, 270)
    
    elma_x = random.randrange(0, ekran_yatay, BOYUT)
    elma_y = random.randrange(0, ekran_dikey, BOYUT)
    yılan_listesi = []
    yılan_uzunlugu = 4
    skor = 0
    en_yuksek_skor = 0
    oyun_durumu = "MENU"

    tekrar_buton = pygame.Rect(ekran_yatay // 2 - 220, ekran_dikey // 2 + 20, 200, 60)
    menu_buton = pygame.Rect(ekran_yatay // 2 + 20, ekran_dikey // 2 + 20, 200, 60)
    font = pygame.font.SysFont("arial", 36, bold=True)

    # 1. Ejderha başı
    bas_resmi = pygame.image.load("dragon_head.png").convert_alpha()
    bas_resmi = pygame.transform.scale(bas_resmi, (BOYUT, BOYUT))

    # 2. Ejderha gövdesi
    govde_resmi = pygame.image.load("dragon_body.png").convert_alpha()
    govde_resmi = pygame.transform.scale(govde_resmi, (BOYUT, BOYUT))

    # 3. Yem (İnci)
    inci_resmi = pygame.image.load("dragon_pearl.png").convert_alpha()
    inci_resmi = pygame.transform.scale(inci_resmi, (BOYUT, BOYUT))

    # 4. Köşe (Dönüş) Gövdesi
    kose_resmi = pygame.image.load("dragon_corner.png").convert_alpha()
    kose_resmi = pygame.transform.scale(kose_resmi, (BOYUT, BOYUT))

    # 5. Tapınak Arka Planı
    arkaplan_resmi = pygame.image.load("temple_bg.png").convert()
    arkaplan_resmi = pygame.transform.scale(arkaplan_resmi, (ekran_yatay, ekran_dikey))

    # 6. Ejderha Kuyruğu
    kuyruk_resmi = pygame.image.load("dragon_tail.png").convert_alpha()
    kuyruk_resmi = pygame.transform.scale(kuyruk_resmi, (BOYUT, BOYUT))

    bulut_resmi = pygame.image.load("dragon_cloud.png").convert_alpha()
    bulut_resmi = pygame.transform.scale(bulut_resmi, (BOYUT, BOYUT))

    
    adim_ilerleme = 0

    saat = pygame.time.Clock()
    running = True
    def bulut_appear(i):
        for a in range(i+1):
            bx = random.randrange(0, ekran_yatay, BOYUT)
            by = random.randrange(0, ekran_dikey, BOYUT)
            # Bulut elmanın veya ejderhanın kafasının üstüne denk gelirse başka yer seç:
            while (bx == elma_x and by == elma_y) or (bx == grid_x and by == grid_y):
                bx = random.randrange(0, ekran_yatay, BOYUT)
                by = random.randrange(0, ekran_dikey, BOYUT)
            bulutlar.append([bx, by])
    while running:
        # ==========================================
        # 1. MENÜ EKRANI
        # ==========================================
        if oyun_durumu == "MENU":
            ekran.blit(arkaplan_resmi, (0, 0))
            
            baslik = font.render("EJDERHA OYUNU - MENÜ", True, (255, 215, 0))
            rekor_yazi = font.render(f"En Yüksek Skor: {en_yuksek_skor}", True, (255, 255, 255))
            basla_yazi = font.render("Oynamak İçin Ekrana Tıklayın", True, (100, 255, 100))
            ekran.blit(baslik, (ekran_yatay // 2 - baslik.get_width() // 2, ekran_dikey // 2 - 100))
            ekran.blit(rekor_yazi, (ekran_yatay // 2 - rekor_yazi.get_width() // 2, ekran_dikey // 2 - 30))
            ekran.blit(basla_yazi, (ekran_yatay // 2 - basla_yazi.get_width() // 2, ekran_dikey // 2 + 40))

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN:
                    grid_x = 180
                    grid_y = 0
                    hız_x = BOYUT
                    hız_y = 0
                    yon_acisi = 270
                    sonraki_yon = (BOYUT, 0, 270)
                    yılan_listesi = []
                    yılan_uzunlugu = 4
                    skor = 0
                    bulutlar = []
                    adim_ilerleme = 0
                    elma_x = random.randrange(0, ekran_yatay, BOYUT)
                    elma_y = random.randrange(0, ekran_dikey, BOYUT)
                    oyun_durumu = "OYUN"

            pygame.display.update()
            saat.tick(30)

        # ==========================================
        # 2. OYUN BİTTİ EKRANI
        # ==========================================
        elif oyun_durumu == "BITTI":
            ekran.blit(arkaplan_resmi, (0, 0))

            bitis_yazisi = font.render(f"OYUN BİTTİ! Skorun: {skor}", True, (255, 80, 80))
            ekran.blit(bitis_yazisi, (ekran_yatay // 2 - bitis_yazisi.get_width() // 2, ekran_dikey // 2 - 60))

            pygame.draw.rect(ekran, (40, 160, 60), tekrar_buton, border_radius=10)
            tekrar_yazi = font.render("Tekrar Oyna", True, BEYAZ)
            ekran.blit(tekrar_yazi, (tekrar_buton.x + (tekrar_buton.width - tekrar_yazi.get_width()) // 2, tekrar_buton.y + 10))

            pygame.draw.rect(ekran, (180, 120, 30), menu_buton, border_radius=10)
            menu_yazi = font.render("Menü", True, BEYAZ)
            ekran.blit(menu_yazi, (menu_buton.x + (menu_buton.width - menu_yazi.get_width()) // 2, menu_buton.y + 10))

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if tekrar_buton.collidepoint(event.pos):
                        grid_x = 180
                        grid_y = 0
                        hız_x = BOYUT
                        hız_y = 0
                        yon_acisi = 270
                        sonraki_yon = (BOYUT, 0, 270)
                        yılan_listesi = []
                        yılan_uzunlugu = 4
                        skor = 0
                        bulutlar = []
                        adim_ilerleme = 0
                        elma_x = random.randrange(0, ekran_yatay, BOYUT)
                        elma_y = random.randrange(0, ekran_dikey, BOYUT)
                        while [elma_x, elma_y] in bulutlar:
                            elma_x = random.randrange(0, ekran_yatay, BOYUT)
                            elma_y = random.randrange(0, ekran_dikey, BOYUT)
                        oyun_durumu = "OYUN"
                    elif menu_buton.collidepoint(event.pos):
                        oyun_durumu = "MENU"

            pygame.display.update()
            saat.tick(30)

        # ==========================================
        # 3. NORMAL OYUN EKRANI (GERÇEK 60 FPS KAYAR HAREKET)
        # ==========================================
        elif oyun_durumu == "OYUN":
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN:
                    dokunulan_x, dokunulan_y = event.pos
                    if hız_x == 0:
                        if dokunulan_x > grid_x:
                            sonraki_yon = (BOYUT, 0, 270)
                        else:
                            sonraki_yon = (-BOYUT, 0, 90)
                    elif hız_y == 0:
                        if dokunulan_y < grid_y:
                            sonraki_yon = (0, -BOYUT, 0)
                        else:
                            sonraki_yon = (0, BOYUT, 180)

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    if event.key == pygame.K_RIGHT and hız_x == 0:
                        sonraki_yon = (BOYUT, 0, 270)
                    elif event.key == pygame.K_LEFT and hız_x == 0:
                        sonraki_yon = (-BOYUT, 0, 90)
                    elif event.key == pygame.K_UP and hız_y == 0:
                        sonraki_yon = (0, -BOYUT, 0)
                    elif event.key == pygame.K_DOWN and hız_y == 0:
                        sonraki_yon = (0, BOYUT, 180)

            # --- MANTIKSAL ADIM (Yeni hücreye tam oturulduğunda) ---
            if adim_ilerleme == 0:
                if grid_x == elma_x and grid_y == elma_y:
                    elma_x = random.randrange(0, ekran_yatay, BOYUT)
                    elma_y = random.randrange(0, ekran_dikey, BOYUT)
                    yılan_uzunlugu += 1
                    skor += 1
                    if skor >= 3 and skor < 10:
                        i = 0  # 1 bulut çıkar
                        bulut_appear(i)
                    elif skor >= 10 and skor < 20:
                        i = 1  # 2 bulut çıkar
                        bulut_appear(i)
                    elif skor >= 20 and skor < 30:
                        i = 2  # 3 bulut çıkar
                        bulut_appear(i)
                    elif skor >= 30 and skor < 40:
                        i = 3  # 4 bulut çıkar
                        bulut_appear(i)
                    elif skor >= 40:
                        i = 4 + (skor - 40) // 25
                        bulut_appear(i)

                    if skor == 5:
                        ADIM_HIZI = 8
                    elif skor == 15:
                        ADIM_HIZI = 10
                    elif skor == 25:
                        ADIM_HIZI = 12
                    elif skor == 35:
                        ADIM_HIZI = 15 
                hız_x, hız_y, yon_acisi = sonraki_yon
                
                grid_x += hız_x
                grid_y += hız_y

                # Kenarlardan geçiş
                if grid_x >= ekran_yatay:
                    grid_x = 0
                elif grid_x < 0:
                    grid_x = ekran_yatay - BOYUT
                if grid_y >= ekran_dikey:
                    grid_y = 0
                elif grid_y < 0:
                    grid_y = ekran_dikey - BOYUT

                yılan_basi = [grid_x, grid_y, yon_acisi]
                yılan_listesi.append(yılan_basi)
                if len(yılan_listesi) > yılan_uzunlugu:
                    del yılan_listesi[0]

                # Kendine çarpma kontrolü
                for parca in yılan_listesi[:-1]:
                    if parca[0] == grid_x and parca[1] == grid_y:
                        if skor > en_yuksek_skor:
                            en_yuksek_skor = skor
                        oyun_durumu = "BITTI"

                # Buluta çarpma kontrolü
                for bulut in bulutlar:
                    if grid_x == bulut[0] and grid_y == bulut[1]:
                        if skor > en_yuksek_skor:
                            en_yuksek_skor = skor
                        oyun_durumu = "BITTI"

            # --- ÇİZİM ---
            ekran.blit(arkaplan_resmi, (0, 0))

            # 1. KUYRUK (Her karede 6 piksel kayarak önündeki parçaya doğru akar)
            if len(yılan_listesi) >= 2:
                kuyruk = yılan_listesi[0]
                kuyruk_onundeki = yılan_listesi[1]
                kuyruk_acisi = kuyruk_onundeki[2]
                
                kx, ky = float(kuyruk[0]), float(kuyruk[1])
                if kuyruk_acisi == 270:
                    kx += adim_ilerleme
                elif kuyruk_acisi == 90:
                    kx -= adim_ilerleme
                elif kuyruk_acisi == 0:
                    ky -= adim_ilerleme
                elif kuyruk_acisi == 180:
                    ky += adim_ilerleme

                donmus_kuyruk = pygame.transform.rotate(kuyruk_resmi, kuyruk_acisi)
                ekran.blit(donmus_kuyruk, (kx, ky))

            # 2. ORTA GÖVDE VE KÖŞELER
            for index in range(1, len(yılan_listesi) - 1):
                parca = yılan_listesi[index]
                eski_aci = parca[2]
                yeni_aci = yılan_listesi[index + 1][2]

                # Kafa veya kuyruğun kısmen içinde bulunduğu düz parçaları kırp (üst üste binmesin)
                kutu_kirp = None
                if index == 1 and index == len(yılan_listesi) - 2 and eski_aci == yeni_aci:
                    k1 = kuyruk_onu_kutu(parca[0], parca[1], eski_aci, adim_ilerleme, BOYUT)
                    k2 = kafa_arkasi_kutu(parca[0], parca[1], yeni_aci, adim_ilerleme, BOYUT)
                    kutu_kirp = k1.clip(k2)
                elif index == 1 and eski_aci == yeni_aci:
                    kutu_kirp = kuyruk_onu_kutu(parca[0], parca[1], eski_aci, adim_ilerleme, BOYUT)
                elif index == len(yılan_listesi) - 2 and eski_aci == yeni_aci:
                    kutu_kirp = kafa_arkasi_kutu(parca[0], parca[1], yeni_aci, adim_ilerleme, BOYUT)

                if kutu_kirp is not None:
                    ekran.set_clip(kutu_kirp)

                if eski_aci == yeni_aci:
                    donmus_govde = pygame.transform.rotate(govde_resmi, eski_aci)
                    ekran.blit(donmus_govde, (parca[0], parca[1]))
                else:
                    if (eski_aci == 0 and yeni_aci == 270) or (eski_aci == 90 and yeni_aci == 180):
                        kose_acisi = 0
                    elif (eski_aci == 270 and yeni_aci == 0) or (eski_aci == 180 and yeni_aci == 90):
                        kose_acisi = 180
                    elif (eski_aci == 270 and yeni_aci == 180) or (eski_aci == 0 and yeni_aci == 90):
                        kose_acisi = 270
                    else:
                        kose_acisi = 90

                    donmus_kose = pygame.transform.rotate(kose_resmi, kose_acisi)
                    ekran.blit(donmus_kose, (parca[0], parca[1]))

                if kutu_kirp is not None:
                    ekran.set_clip(None)

            # 3. KAFA (Her karede 6 piksel kayarak yeni hücreye doğru pürüzsüzce uzanır!)
            if len(yılan_listesi) >= 2:
                bas = yılan_listesi[-1]
                bas_acisi = bas[2]
                geriye_kalan = BOYUT - adim_ilerleme

                bx, by = float(bas[0]), float(bas[1])
                if bas_acisi == 270:
                    bx -= geriye_kalan
                elif bas_acisi == 90:
                    bx += geriye_kalan
                elif bas_acisi == 0:
                    by += geriye_kalan
                elif bas_acisi == 180:
                    by -= geriye_kalan

                donmus_bas = pygame.transform.rotate(bas_resmi, bas_acisi)
                ekran.blit(donmus_bas, (bx, by))

            ekran.blit(inci_resmi, (elma_x, elma_y))
            for bulut in bulutlar:
                ekran.blit(bulut_resmi, (bulut[0], bulut[1]))

            skor_yazisi = font.render(f"Skor: {skor}", True, (255, 215, 0))
            ekran.blit(skor_yazisi, (15, 15))

            pygame.display.update()

            # --- SAYAÇ ARTIRIMI ÇİZİMDEN SONRA YAPILMALI! ---
            adim_ilerleme += ADIM_HIZI
            if adim_ilerleme >= BOYUT:
                adim_ilerleme = 0

            saat.tick(60)  # Gerçek 60 FPS!

        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())
